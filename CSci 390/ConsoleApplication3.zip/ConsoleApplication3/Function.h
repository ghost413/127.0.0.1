#pragma once

void Msg(const char *Message) {};