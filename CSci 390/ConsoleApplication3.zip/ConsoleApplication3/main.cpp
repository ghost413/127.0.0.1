#include "Function.h"
#include <iostream>

int main(void) {

	Msg("Hello");
	Msg("World");

	
	return 0;
}

